# Server configuration

در `MainActivity.java` مقدار `SERVER` را از:
`http://10.0.2.2:8000`
به دامنه HTTPS سرور واقعی تغییر دهید، نمونه:
`https://api.example.com`

برای انتشار Play Store از HTTPS استفاده کنید.

package com.example.khaneh3d;
import android.app.*; import android.os.*; import android.content.*; import android.database.Cursor; import android.net.Uri;import com.google.firebase.firestore.FirebaseFirestore; import com.google.firebase.firestore.QueryDocumentSnapshot;
import android.provider.OpenableColumns; import android.webkit.*; import android.widget.*; import java.io.*; import java.net.*; import java.util.UUID;

public class MainActivity extends Activity {
 WebView web; Uri selected; static final int PICK=10; FirebaseFirestore db;
 // Change this to your server. For emulator + local PC use http://10.0.2.2:8000
 static final String SERVER="http://10.0.2.2:8000";
 public void onCreate(Bundle b){super.onCreate(b);
  web=new WebView(this); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true);
  db = FirebaseFirestore.getInstance();  web.addJavascriptInterface(new Bridge(),"Android"); setContentView(web); web.loadUrl("file:///android_asset/index.html");
 }
 class Bridge {
  @JavascriptInterface public void loadHouses(){
   db.collection("houses").get().addOnCompleteListener(task -> {
    if(!task.isSuccessful()){
      String msg = task.getException()==null ? "خطای دریافت آگهی‌ها" : task.getException().getMessage();
      runOnUiThread(() -> web.evaluateJavascript("firestoreError("+quoteJs(msg)+")", null));
      return;
    }
    StringBuilder json = new StringBuilder("[");
    boolean first = true;
    for(QueryDocumentSnapshot d : task.getResult()){
      if(!first) json.append(",");
      first = false;
      json.append("{")
        .append("\"id\":").append(quoteJson(d.getId())).append(",")
        .append("\"title\":").append(quoteJson(d.getString("title"))).append(",")
        .append("\"transactionType\":").append(quoteJson(d.getString("transactionType"))).append(",")
        .append("\"price\":").append(quoteJson(d.getString("price"))).append(",")
        .append("\"address\":").append(quoteJson(d.getString("address"))).append(",")
        .append("\"description\":").append(quoteJson(d.getString("description")))
        .append("}");
    }
    json.append("]");
    final String payload = json.toString();
    runOnUiThread(() -> web.evaluateJavascript("firestoreHouses("+payload+")", null));
   });
  }
  String quoteJson(String s){
   if(s==null) return "null";
   return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r")+"\"";
  }
  String quoteJs(String s){
   if(s==null) s="خطای ناشناخته";
   return "'"+s.replace("\\","\\\\").replace("'","\\'").replace("\n"," ")+"'";
  }

  @JavascriptInterface public void pickVideo(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("video/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);}
  @JavascriptInterface public void upload(String room){ if(selected==null){toast("ابتدا ویدئو را انتخاب کنید");return;} new Thread(()->send(room)).start(); }
  void send(String room){
   try{
    URL url=new URL(SERVER+"/api/rooms/"+URLEncoder.encode(room,"UTF-8")+"/capture");
    String boundary="----Khaneh3D"+UUID.randomUUID(); HttpURLConnection c=(HttpURLConnection)url.openConnection();
    c.setRequestMethod("POST"); c.setDoOutput(true); c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
    OutputStream out=c.getOutputStream(); String name="capture.mp4";
    write(out,"--"+boundary+"\r\nContent-Disposition: form-data; name=\"property_id\"\r\n\r\ndemo\r\n");
    write(out,"--"+boundary+"\r\nContent-Disposition: form-data; name=\"video\"; filename=\""+name+"\"\r\nContent-Type: video/mp4\r\n\r\n");
    InputStream in=getContentResolver().openInputStream(selected); byte[] buf=new byte[65536]; int n; while((n=in.read(buf))!=-1)out.write(buf,0,n); in.close();
    write(out,"\r\n--"+boundary+"--\r\n"); out.close();
    final int code=c.getResponseCode(); runOnUiThread(()->web.evaluateJavascript("uploadDone("+code+")",null));
   }catch(Exception e){runOnUiThread(()->web.evaluateJavascript("uploadError("+JSONObjectQuote(e.getMessage())+")",null));}
  }
  void write(OutputStream o,String s)throws Exception{o.write(s.getBytes("UTF-8"));}
  String JSONObjectQuote(String s){return "'"+(s==null?"خطای اتصال":s.replace("\\","\\\\").replace("'","\\'").replace("\n"," "))+"'";}
 }
 protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==PICK&&c==RESULT_OK&&d!=null){selected=d.getData();web.evaluateJavascript("videoSelected()",null);}}
 void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
}
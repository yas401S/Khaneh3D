# راهنمای استقرار خانه 3D

1. یک VPS/GPU server تهیه کنید.
2. Docker و Docker Compose نصب کنید.
3. فایل `backend/.env.example` را به `.env` کپی و مقادیر واقعی را وارد کنید.
4. `docker compose -f docker-compose.production.yml up -d --build`
5. DNS دامنه API را تنظیم کنید.
6. HTTPS را با reverse proxy مثل Nginx/Caddy فعال کنید.
7. در Android مقدار SERVER را روی آدرس HTTPS قرار دهید.
8. برای پردازش 3D، روی worker دارای GPU، FFmpeg و COLMAP نصب کنید.
9. برای محصول بزرگ، worker را به Redis/RabbitMQ/SQS متصل کنید و فایل‌ها را در S3-compatible storage نگه دارید.

این بسته کد استقرار را آماده می‌کند؛ تهیه سرور، دامنه، کلیدهای ابری و اجرای سرویس‌ها نیازمند محیط واقعی شماست.

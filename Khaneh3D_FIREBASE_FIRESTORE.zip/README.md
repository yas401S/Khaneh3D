# خانه 3D — Complete MVP v2

شامل:
- اپ Android
- Backend FastAPI
- ثبت‌نام کاربر
- ثبت ملک
- فهرست و جزئیات ملک
- تعریف اتاق‌های متعدد
- آپلود ویدئو برای هر اتاق
- Job پردازش سه‌بعدی
- endpoint تور هر ملک و جابه‌جایی بین اتاق‌ها
- آماده اتصال Viewer به GLB/360
- Docker Compose

برای اجرای سرور:
docker compose up --build

برای بازسازی واقعی سه‌بعدی، روی سرور GPU، FFmpeg و COLMAP نصب شود. برای تولید تجاری، دیتابیس واقعی، Object Storage، صف پردازش، احراز هویت امن و Viewer WebGL/Three.js را جایگزین نسخه MVP کنید.

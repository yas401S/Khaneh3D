# Khaneh3D V5 Backend
API دریافت ویدئوی اتاق و صف پردازش سه‌بعدی.

## اجرا
```bash
cd backend
python -m venv .venv
# فعال‌سازی محیط مجازی
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

برای بازسازی واقعی، COLMAP را روی سرور/GPU نصب کنید. در این نسخه اگر `colmap` و `ffmpeg` موجود باشند، ویدئو به فریم تبدیل شده و `colmap automatic_reconstructor` اجرا می‌شود.

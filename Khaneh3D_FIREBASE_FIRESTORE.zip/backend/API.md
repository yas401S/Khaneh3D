# Khaneh3D API

- GET `/api/health`
- POST `/api/auth/register`
- POST `/api/properties`
- GET `/api/properties`
- GET `/api/properties/{id}`
- POST `/api/properties/{id}/rooms`
- POST `/api/rooms/{room_id}/capture`
- GET `/api/jobs/{job_id}`
- GET `/api/rooms/{room_id}/tour`

برای انتشار واقعی، JWT/OAuth، PostgreSQL، S3-compatible storage و HTTPS اضافه شود.

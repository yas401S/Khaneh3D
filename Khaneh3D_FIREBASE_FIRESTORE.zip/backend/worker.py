"""
Khaneh3D GPU worker scaffold.
Install ffmpeg + COLMAP on the worker image/host.
A production queue (Redis/RabbitMQ/SQS) should feed jobs here.
"""
import os, shutil, subprocess, time
def process(job_dir):
    video=os.path.join(job_dir,"capture.mp4")
    frames=os.path.join(job_dir,"images"); os.makedirs(frames,exist_ok=True)
    ff=shutil.which("ffmpeg"); col=shutil.which("colmap")
    if not ff: raise RuntimeError("ffmpeg is not installed")
    subprocess.run([ff,"-y","-i",video,"-vf","fps=2",os.path.join(frames,"%06d.jpg")],check=True)
    if not col: raise RuntimeError("COLMAP is not installed")
    out=os.path.join(job_dir,"colmap"); os.makedirs(out,exist_ok=True)
    subprocess.run([col,"automatic_reconstructor","--workspace_path",out,
                    "--image_path",frames,"--data_type","VIDEO"],check=True)
    return out

if __name__=="__main__":
    print("Khaneh3D GPU worker ready. Connect this worker to your queue.")
    while True: time.sleep(60)

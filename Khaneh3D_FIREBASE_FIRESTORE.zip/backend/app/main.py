import os, uuid, json, shutil, subprocess, threading, time
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),".."))
DATA=os.path.join(ROOT,"data"); UP=os.path.join(DATA,"uploads"); JOBS=os.path.join(DATA,"jobs")
DB=os.path.join(DATA,"db.json")
for p in (UP,JOBS): os.makedirs(p,exist_ok=True)
if not os.path.exists(DB): open(DB,"w").write(json.dumps({"users":[],"properties":[],"rooms":[]},ensure_ascii=False))

app=FastAPI(title="Khaneh3D Complete API",version="2.0")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
app.mount("/uploads",StaticFiles(directory=UP),name="uploads")
app.mount("/jobs",StaticFiles(directory=JOBS),name="jobs")
jobs={}

def read_db():
    with open(DB,encoding="utf-8") as f:return json.load(f)
def write_db(x):
    with open(DB,"w",encoding="utf-8") as f:json.dump(x,f,ensure_ascii=False,indent=2)

@app.get("/api/health")
def health(): return {"ok":True,"service":"Khaneh3D","version":"2.0"}

@app.post("/api/auth/register")
def register(phone:str=Form(...),name:str=Form("")):
    d=read_db()
    if any(u["phone"]==phone for u in d["users"]): raise HTTPException(409,"کاربر وجود دارد")
    u={"id":str(uuid.uuid4()),"phone":phone,"name":name}
    d["users"].append(u); write_db(d); return {"user":u}

@app.post("/api/properties")
def create_property(owner_id:str=Form(...),title:str=Form(...),city:str=Form(...),address:str=Form(""),price:str=Form(""),rent:str=Form(""),area:str=Form(""),bedrooms:str=Form("")):
    d=read_db(); p={"id":str(uuid.uuid4()),"owner_id":owner_id,"title":title,"city":city,"address":address,"price":price,"rent":rent,"area":area,"bedrooms":bedrooms,"rooms":[]}
    d["properties"].append(p); write_db(d); return p

@app.get("/api/properties")
def properties(): return read_db()["properties"]

@app.get("/api/properties/{pid}")
def property_detail(pid:str):
    d=read_db()
    p=next((x for x in d["properties"] if x["id"]==pid),None)
    if not p: raise HTTPException(404,"ملک پیدا نشد")
    p["rooms"]=[r for r in d["rooms"] if r["property_id"]==pid]
    return p

@app.post("/api/properties/{pid}/rooms")
def add_room(pid:str,name:str=Form(...),order:int=Form(0)):
    d=read_db()
    if not any(x["id"]==pid for x in d["properties"]): raise HTTPException(404,"ملک پیدا نشد")
    r={"id":str(uuid.uuid4()),"property_id":pid,"name":name,"order":order,"tour_url":None,"model_url":None}
    d["rooms"].append(r); write_db(d); return r

def process(job_id,room_id,path):
    j=jobs[job_id]; work=os.path.join(JOBS,job_id); frames=os.path.join(work,"images"); os.makedirs(frames,exist_ok=True)
    try:
        j.update(status="processing",progress=10,message="استخراج فریم‌ها")
        ff=shutil.which("ffmpeg")
        if ff: subprocess.run([ff,"-y","-i",path,"-vf","fps=2",os.path.join(frames,"%06d.jpg")],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        j.update(progress=45,message="تحلیل تصاویر")
        col=shutil.which("colmap")
        if col and os.listdir(frames):
            out=os.path.join(work,"colmap");os.makedirs(out,exist_ok=True)
            subprocess.run([col,"automatic_reconstructor","--workspace_path",out,"--image_path",frames,"--data_type","VIDEO"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            j["model_url"]=f"/jobs/{job_id}/colmap"
        j.update(status="completed",progress=100,message="پردازش تمام شد")
        d=read_db()
        for r in d["rooms"]:
            if r["id"]==room_id:
                r["model_url"]=j.get("model_url")
                r["tour_url"]=f"/api/rooms/{room_id}/tour"
        write_db(d)
    except Exception as e:j.update(status="failed",message=str(e))

@app.post("/api/rooms/{room_id}/capture")
async def capture(room_id:str,video:UploadFile=File(...)):
    jid=str(uuid.uuid4()); ext=os.path.splitext(video.filename or ".mp4")[1] or ".mp4"; path=os.path.join(UP,jid+ext)
    with open(path,"wb") as f:
        while c:=await video.read(1024*1024):f.write(c)
    jobs[jid]={"job_id":jid,"room_id":room_id,"status":"queued","progress":0}
    threading.Thread(target=process,args=(jid,room_id,path),daemon=True).start()
    return jobs[jid]

@app.get("/api/jobs/{jid}")
def job(jid:str):
    if jid not in jobs: raise HTTPException(404,"job not found")
    return jobs[jid]

@app.get("/api/rooms/{rid}/tour")
def tour(rid:str):
    d=read_db(); r=next((x for x in d["rooms"] if x["id"]==rid),None)
    if not r: raise HTTPException(404,"اتاق پیدا نشد")
    siblings=[x for x in d["rooms"] if x["property_id"]==r["property_id"]]
    siblings.sort(key=lambda x:x.get("order",0))
    return {"room":r,"rooms":siblings}
